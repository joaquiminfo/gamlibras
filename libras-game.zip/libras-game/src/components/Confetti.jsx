import React, { useEffect, useState } from 'react'

const COLORS = ['#FFD93D','#FF6B35','#06D6A0','#7B2FBE','#FF4D8D','#118AB2']

export default function Confetti({ active }) {
  const [pieces, setPieces] = useState([])

  useEffect(() => {
    if (!active) { setPieces([]); return }
    const arr = Array.from({ length: 40 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      delay: Math.random() * 1.5,
      duration: 2 + Math.random() * 2,
      size: 6 + Math.random() * 10,
      shape: Math.random() > 0.5 ? 'circle' : 'rect',
    }))
    setPieces(arr)
    const t = setTimeout(() => setPieces([]), 4000)
    return () => clearTimeout(t)
  }, [active])

  if (!pieces.length) return null

  return (
    <div style={{ position:'fixed', inset:0, pointerEvents:'none', zIndex:9999, overflow:'hidden' }}>
      {pieces.map(p => (
        <div key={p.id} style={{
          position:'absolute',
          left: p.x + '%',
          top: -20,
          width: p.size,
          height: p.size,
          background: p.color,
          borderRadius: p.shape === 'circle' ? '50%' : '2px',
          animation: `confettiFall ${p.duration}s ${p.delay}s ease-in forwards`,
        }} />
      ))}
    </div>
  )
}

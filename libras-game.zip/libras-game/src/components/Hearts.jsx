import React from 'react'

export default function Hearts({ count, max = 5 }) {
  return (
    <div style={{ display:'flex', gap:4 }}>
      {Array.from({ length: max }, (_, i) => (
        <span key={i} style={{
          fontSize: 20,
          filter: i < count ? 'none' : 'grayscale(1) opacity(0.3)',
          transition: 'filter 0.3s',
          animation: i < count ? 'pulse 2s infinite' : 'none',
          animationDelay: i * 0.1 + 's',
        }}>❤️</span>
      ))}
    </div>
  )
}

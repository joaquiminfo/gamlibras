import React from 'react'
import { CATEGORIES, SIGNS, getLevel } from '../data'
import XPBar from './XPBar'
import Hearts from './Hearts'

export default function Home({ gameState, onSelectCategory, onOpenProfile }) {
  const { totalXP, streak, hearts, level, completedCategories, totalLessons } = gameState

  return (
    <div style={{ minHeight:'100vh', background:'var(--dark)' }}>
      {/* Header */}
      <header style={{
        position:'sticky', top:0, zIndex:100,
        background:'rgba(13,13,26,0.95)',
        backdropFilter:'blur(12px)',
        borderBottom:'1px solid #1E2A45',
        padding:'14px 20px',
      }}>
        <div style={{ maxWidth:600, margin:'0 auto', display:'flex', flexDirection:'column', gap:10 }}>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <div style={{ display:'flex', alignItems:'center', gap:10 }}>
              <span style={{ fontSize:28 }}>🤟</span>
              <div>
                <div style={{ fontFamily:"'Baloo 2',sans-serif", fontSize:20, fontWeight:800, lineHeight:1 }}>LIBRAS Quest</div>
                <div style={{ fontSize:11, color:'var(--muted)' }}>{level.label}</div>
              </div>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:12 }}>
              <div style={{
                display:'flex', alignItems:'center', gap:5,
                background:'#1E2A45', borderRadius:12, padding:'6px 12px',
              }}>
                <span style={{ fontSize:16 }}>🔥</span>
                <span style={{ fontWeight:800, fontSize:14, color: streak > 0 ? '#FF6B35' : 'var(--muted)' }}>
                  {streak}
                </span>
              </div>
              <Hearts count={hearts} />
              <button onClick={onOpenProfile} style={{
                background:'#1E2A45', border:'none', borderRadius:12,
                width:36, height:36, fontSize:18, cursor:'pointer',
                transition:'background 0.2s',
              }}>👤</button>
            </div>
          </div>
          <XPBar xp={totalXP} level={level} />
        </div>
      </header>

      <main style={{ maxWidth:600, margin:'0 auto', padding:'24px 16px' }}>
        {/* Daily stats */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:10, marginBottom:28 }}>
          {[
            { label:'Lições', value:totalLessons, emoji:'📚' },
            { label:'Sequência', value:`${streak} dias`, emoji:'🔥' },
            { label:'XP Total', value:totalXP, emoji:'⚡' },
          ].map(s => (
            <div key={s.label} style={{
              background:'var(--card)',
              borderRadius:16, padding:'14px 12px',
              textAlign:'center',
              border:'1px solid #243050',
            }}>
              <div style={{ fontSize:22 }}>{s.emoji}</div>
              <div style={{ fontWeight:800, fontSize:18, color:'var(--text)', marginTop:4 }}>{s.value}</div>
              <div style={{ fontSize:11, color:'var(--muted)' }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Section title */}
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:16 }}>
          <div style={{ width:4, height:20, background:'#7B2FBE', borderRadius:2 }}/>
          <h2 style={{ fontFamily:"'Baloo 2',sans-serif", fontSize:18, fontWeight:700 }}>Categorias</h2>
        </div>

        {/* Category grid */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
          {CATEGORIES.map((cat, i) => {
            const done = completedCategories.includes(cat.id)
            const total = SIGNS[cat.id]?.length || 0
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                style={{
                  background: done
                    ? `linear-gradient(135deg, ${cat.color}30, ${cat.color}10)`
                    : 'var(--card)',
                  border: done
                    ? `2px solid ${cat.color}80`
                    : '2px solid #243050',
                  borderRadius:20, padding:'18px 16px',
                  textAlign:'left', cursor:'pointer',
                  transition:'all 0.2s',
                  animation: `slideUp 0.4s ${i * 0.05}s both`,
                  position:'relative', overflow:'hidden',
                }}
                onMouseEnter={e => {
                  e.currentTarget.style.transform = 'translateY(-3px)'
                  e.currentTarget.style.boxShadow = `0 8px 24px ${cat.color}30`
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.transform = 'translateY(0)'
                  e.currentTarget.style.boxShadow = 'none'
                }}
              >
                {done && (
                  <div style={{
                    position:'absolute', top:10, right:10,
                    background: cat.color, borderRadius:'50%',
                    width:22, height:22, display:'flex',
                    alignItems:'center', justifyContent:'center',
                    fontSize:12, fontWeight:700,
                  }}>✓</div>
                )}
                <div style={{ fontSize:32, marginBottom:8 }}>{cat.emoji}</div>
                <div style={{ fontWeight:800, fontSize:15, color:'var(--text)' }}>{cat.label}</div>
                <div style={{ fontSize:11, color:'var(--muted)', marginTop:2 }}>{total} sinais · +{cat.xp} XP</div>
                <div style={{ marginTop:10, height:4, background:'#1E2A45', borderRadius:2 }}>
                  <div style={{
                    height:'100%',
                    width: done ? '100%' : '0%',
                    background: cat.color,
                    borderRadius:2,
                    transition:'width 0.8s ease',
                  }}/>
                </div>
              </button>
            )
          })}
        </div>

        {/* Bottom padding */}
        <div style={{ height:32 }} />
      </main>
    </div>
  )
}

import React from 'react'
import { BADGES, LEVELS, CATEGORIES, getLevel, getXPForNext } from '../data'

export default function Profile({ gameState, onBack }) {
  const { totalXP, streak, totalLessons, badges, maxCombo, completedCategories, triedCategories, resetProgress } = gameState
  const level = getLevel(totalXP)
  const pct = getXPForNext(totalXP)

  function confirmReset() {
    if (window.confirm('Tem certeza? Todo o progresso será perdido!')) {
      resetProgress()
      onBack()
    }
  }

  return (
    <div style={{ minHeight:'100vh', background:'var(--dark)', paddingBottom:32 }}>
      {/* Header */}
      <div style={{
        padding:'16px 20px', display:'flex', alignItems:'center', gap:14,
        borderBottom:'1px solid #1E2A45', background:'rgba(13,13,26,0.95)',
        backdropFilter:'blur(12px)', position:'sticky', top:0, zIndex:10,
      }}>
        <button onClick={onBack} style={{
          background:'none', border:'none', color:'var(--muted)',
          fontSize:22, cursor:'pointer',
        }}>←</button>
        <h1 style={{ fontFamily:"'Baloo 2',sans-serif", fontSize:20, fontWeight:800 }}>Meu Perfil</h1>
      </div>

      <div style={{ maxWidth:500, margin:'0 auto', padding:'24px 16px' }}>

        {/* Level card */}
        <div style={{
          background:`linear-gradient(135deg, ${level.color}25, ${level.color}10)`,
          border:`2px solid ${level.color}50`,
          borderRadius:24, padding:'24px 20px', marginBottom:20,
          textAlign:'center',
          animation:'glow 3s infinite',
          boxShadow:`0 0 40px ${level.color}20`,
        }}>
          <div style={{ fontSize:56 }}>🎖️</div>
          <div style={{ fontFamily:"'Baloo 2',sans-serif", fontSize:28, fontWeight:800, color:level.color }}>
            {level.label}
          </div>
          <div style={{ color:'var(--muted)', fontSize:13, marginBottom:16 }}>Nível {level.level}</div>

          {/* XP bar */}
          <div style={{ background:'#1E2A45', borderRadius:99, height:16, overflow:'hidden', marginBottom:6 }}>
            <div style={{
              height:'100%', width:pct+'%',
              background:`linear-gradient(90deg, ${level.color}, ${level.color}cc)`,
              borderRadius:99, transition:'width 1s ease',
              boxShadow:`0 0 10px ${level.color}80`,
            }}/>
          </div>
          <div style={{ fontSize:12, color:'var(--muted)' }}>{totalXP} XP · {Math.round(pct)}% para o próximo nível</div>
        </div>

        {/* Stats grid */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:10, marginBottom:20 }}>
          {[
            { label:'XP Total', value:totalXP, emoji:'⚡', color:'#FFD93D' },
            { label:'Sequência', value:`${streak} dias`, emoji:'🔥', color:'#FF6B35' },
            { label:'Lições', value:totalLessons, emoji:'📚', color:'#06D6A0' },
            { label:'Melhor Combo', value:maxCombo, emoji:'💥', color:'#7B2FBE' },
            { label:'Categorias Feitas', value:completedCategories.length, emoji:'✅', color:'#118AB2' },
            { label:'Badges', value:badges.length, emoji:'🏅', color:'#FF4D8D' },
          ].map(s => (
            <div key={s.label} style={{
              background:'var(--card)', borderRadius:16, padding:'16px',
              border:'1px solid #243050',
            }}>
              <span style={{ fontSize:22 }}>{s.emoji}</span>
              <div style={{ fontWeight:800, fontSize:22, color:s.color, marginTop:4 }}>{s.value}</div>
              <div style={{ fontSize:11, color:'var(--muted)' }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Level journey */}
        <div style={{ marginBottom:20 }}>
          <h3 style={{ fontFamily:"'Baloo 2',sans-serif", fontSize:16, fontWeight:700, marginBottom:12, display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ width:4, height:18, background:'#7B2FBE', borderRadius:2 }}/>
            Jornada de Níveis
          </h3>
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {LEVELS.map((l, i) => {
              const active = level.level === l.level
              const done = totalXP >= l.min
              return (
                <div key={l.level} style={{
                  display:'flex', alignItems:'center', gap:12,
                  background: active ? `${l.color}20` : done ? '#1E2A45' : '#1A1A2E',
                  border: active ? `2px solid ${l.color}` : `1px solid ${done ? '#243050' : '#1A1A2E'}`,
                  borderRadius:14, padding:'10px 14px',
                }}>
                  <div style={{
                    width:32, height:32, borderRadius:'50%',
                    background: done ? l.color : '#243050',
                    display:'flex', alignItems:'center', justifyContent:'center',
                    fontSize:13, fontWeight:800, color:'#fff',
                    boxShadow: done ? `0 0 12px ${l.color}60` : 'none',
                  }}>{l.level}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:700, fontSize:14, color: done ? 'var(--text)' : 'var(--muted)' }}>{l.label}</div>
                    <div style={{ fontSize:11, color:'var(--muted)' }}>{l.min} XP</div>
                  </div>
                  {active && <span style={{ fontSize:12, color:l.color, fontWeight:700 }}>← ATUAL</span>}
                  {done && !active && <span style={{ fontSize:16 }}>✅</span>}
                </div>
              )
            })}
          </div>
        </div>

        {/* Badges */}
        <div style={{ marginBottom:24 }}>
          <h3 style={{ fontFamily:"'Baloo 2',sans-serif", fontSize:16, fontWeight:700, marginBottom:12, display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ width:4, height:18, background:'#FFD93D', borderRadius:2 }}/>
            Badges ({badges.length}/{BADGES.length})
          </h3>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:8 }}>
            {BADGES.map(b => {
              const unlocked = badges.includes(b.id)
              return (
                <div key={b.id} style={{
                  background: unlocked ? 'linear-gradient(135deg, #FFD93D20, #FF6B3510)' : '#1A1A2E',
                  border: unlocked ? '2px solid #FFD93D60' : '1px solid #243050',
                  borderRadius:16, padding:'14px 10px',
                  textAlign:'center',
                  filter: unlocked ? 'none' : 'grayscale(1)',
                  opacity: unlocked ? 1 : 0.5,
                  transition:'all 0.2s',
                }}>
                  <div style={{ fontSize:28 }}>{b.emoji}</div>
                  <div style={{ fontSize:11, fontWeight:700, color: unlocked ? 'var(--text)' : 'var(--muted)', marginTop:4, lineHeight:1.3 }}>
                    {b.label}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Reset */}
        <button
          onClick={confirmReset}
          style={{
            width:'100%', background:'transparent', border:'2px solid #EF233C40',
            borderRadius:14, padding:'14px', color:'#EF233C80',
            fontWeight:700, fontSize:14, cursor:'pointer', transition:'all 0.2s',
          }}
          onMouseEnter={e => { e.currentTarget.style.borderColor='#EF233C'; e.currentTarget.style.color='#EF233C' }}
          onMouseLeave={e => { e.currentTarget.style.borderColor='#EF233C40'; e.currentTarget.style.color='#EF233C80' }}
        >
          🗑️ Resetar Progresso
        </button>
      </div>
    </div>
  )
}

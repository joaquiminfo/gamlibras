import React from 'react'
import { getXPForNext } from '../data'

export default function XPBar({ xp, level }) {
  const pct = getXPForNext(xp)

  return (
    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
      <div style={{
        background: level.color,
        color: '#fff',
        fontFamily: "'Baloo 2', sans-serif",
        fontWeight: 700,
        fontSize: 13,
        borderRadius: 10,
        padding: '3px 10px',
        whiteSpace: 'nowrap',
        boxShadow: `0 0 12px ${level.color}60`,
      }}>
        Nv {level.level}
      </div>
      <div style={{ flex:1, background:'#1E2A45', borderRadius:99, height:14, overflow:'hidden', position:'relative' }}>
        <div style={{
          height:'100%',
          width: pct + '%',
          background: `linear-gradient(90deg, ${level.color}, ${level.color}cc)`,
          borderRadius:99,
          transition: 'width 0.6s ease',
          boxShadow: `0 0 8px ${level.color}80`,
        }} />
        <span style={{
          position:'absolute', inset:0,
          display:'flex', alignItems:'center', justifyContent:'center',
          fontSize:9, fontWeight:700, color:'rgba(255,255,255,0.7)',
        }}>
          {Math.round(pct)}%
        </span>
      </div>
      <span style={{ fontSize:12, color:'#8892AA', whiteSpace:'nowrap' }}>{xp} XP</span>
    </div>
  )
}

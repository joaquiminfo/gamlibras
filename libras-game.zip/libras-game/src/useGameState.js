import { useState, useEffect, useCallback } from 'react'
import { BADGES, getLevel } from './data'

const INITIAL_STATE = {
  totalXP: 0,
  totalLessons: 0,
  streak: 0,
  lastPlayDate: null,
  completedCategories: [],
  triedCategories: [],
  maxCombo: 0,
  currentCombo: 0,
  badges: [],
  hearts: 5,
  fastRound: false,
  comeback: false,
  missStreak: 0,
}

function loadState() {
  try {
    const s = localStorage.getItem('libras_state')
    return s ? { ...INITIAL_STATE, ...JSON.parse(s) } : { ...INITIAL_STATE }
  } catch { return { ...INITIAL_STATE } }
}

function saveState(s) {
  try { localStorage.setItem('libras_state', JSON.stringify(s)) } catch {}
}

export function useGameState() {
  const [state, setState] = useState(loadState)

  useEffect(() => { saveState(state) }, [state])

  // Check & update streak on load
  useEffect(() => {
    const today = new Date().toDateString()
    if (state.lastPlayDate) {
      const last = new Date(state.lastPlayDate)
      const diff = Math.floor((new Date() - last) / 86400000)
      if (diff > 1) {
        setState(s => ({ ...s, streak: 0 }))
      }
    }
  }, [])

  const addXP = useCallback((amount, categoryId) => {
    setState(s => {
      const today = new Date().toDateString()
      const newXP = s.totalXP + amount
      const newStreak = s.lastPlayDate === today ? s.streak
        : s.lastPlayDate === new Date(Date.now() - 86400000).toDateString()
          ? s.streak + 1 : 1

      const newState = {
        ...s,
        totalXP: newXP,
        streak: newStreak,
        lastPlayDate: today,
        triedCategories: s.triedCategories.includes(categoryId)
          ? s.triedCategories : [...s.triedCategories, categoryId],
      }

      // Check badges
      const newBadges = BADGES
        .filter(b => !s.badges.includes(b.id) && b.condition(newState))
        .map(b => b.id)

      return { ...newState, badges: [...s.badges, ...newBadges], _newBadges: newBadges }
    })
  }, [])

  const completeLesson = useCallback((categoryId, perfect) => {
    setState(s => ({
      ...s,
      totalLessons: s.totalLessons + 1,
      completedCategories: s.completedCategories.includes(categoryId)
        ? s.completedCategories : [...s.completedCategories, categoryId],
    }))
  }, [])

  const updateCombo = useCallback((correct) => {
    setState(s => {
      if (correct) {
        const newCombo = s.currentCombo + 1
        const comeback = s.missStreak >= 3 && correct
        return {
          ...s,
          currentCombo: newCombo,
          maxCombo: Math.max(s.maxCombo, newCombo),
          missStreak: 0,
          comeback: comeback || s.comeback,
        }
      } else {
        return { ...s, currentCombo: 0, missStreak: s.missStreak + 1 }
      }
    })
  }, [])

  const loseHeart = useCallback(() => {
    setState(s => ({ ...s, hearts: Math.max(0, s.hearts - 1) }))
  }, [])

  const refillHearts = useCallback(() => {
    setState(s => ({ ...s, hearts: 5 }))
  }, [])

  const setFastRound = useCallback(() => {
    setState(s => ({ ...s, fastRound: true }))
  }, [])

  const resetProgress = useCallback(() => {
    setState({ ...INITIAL_STATE })
    localStorage.removeItem('libras_state')
  }, [])

  const level = getLevel(state.totalXP)

  return {
    ...state,
    level,
    addXP,
    completeLesson,
    updateCombo,
    loseHeart,
    refillHearts,
    setFastRound,
    resetProgress,
  }
}
